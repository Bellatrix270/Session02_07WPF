﻿using _319_Sevriukov_Lombard.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _319_Sevriukov_Lombard
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_ClickRegistration(object sender, RoutedEventArgs e)
        {
            DataBase db = new DataBase();
            bool isAuth = db.IsAuth(EmpLogin.Text, EmpPass.Text);

            if (isAuth)
                MessageBox.Show("Успешная авторизация");
            else
                MessageBox.Show("Неверный логин или пароль");
        }

        private void Button_ClickCancel(object sender, RoutedEventArgs e)
        {
            EmpPass.Text = string.Empty;
            EmpLogin.Text = string.Empty;
        }
    }
}
