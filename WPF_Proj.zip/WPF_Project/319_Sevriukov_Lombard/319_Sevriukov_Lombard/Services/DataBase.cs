﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _319_Sevriukov_Lombard.ModelsDataBase;

namespace _319_Sevriukov_Lombard.Services
{
    public class DataBase
    {
        private readonly LombardEntities db;
        public DataBase()
        {
            db = new LombardEntities();
        }

        public bool IsAuth(string login, string password)
            => db.employees.FirstOrDefault(emp => emp.login == login && emp.password == password) == null ? false : true;

    }
}
