﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using _319_Sevriukov_Lombard.Services;
using System;

namespace _319_Sevriukov_Lombard_Tests
{
    [TestClass]
    public class AuthTests
    {
        [TestMethod]
        public void EmployeesAuthTest()
        {
            DataBase db = new DataBase();

            bool isAuth = db.IsAuth("test", "test");

            Assert.AreEqual(true, isAuth);
        }
    }
}
